xrandr && xrandr --output LVDS1 --primary --mode 1366x768 --pos 0x312 --rotate normal --output DP3 --mode 2560x1080 --pos 1366x0 --rotate normal --right-of LVDS1
