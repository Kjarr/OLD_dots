#!/bin/bash

echo "$(light | cut -d. -f1)"
