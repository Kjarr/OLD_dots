To clear the Fish Greeting create a config.fish file in the .config/fish folder with "set fish_greeting" as the contents. 

In the FIT Archive, 
Place fonts in /usr/share
Google Cursurs in /usr/share/icons/
Paper-Vimix in /usr/share/icons

And the remaining Vimix themes in the /usr/share/themes folder.
