Install Me's

Sourced by Pacman -Qqe

#Security
clamtk ufw

#General Tools
firefox-i18n-en-gb geany geary

#Shell
fish ranger elinks terminator

#Additional Tools
gnome-disk-utility gnome-keyring woeusb scrot

#Audio
pavucontrol pulseeffects

#Fonts (may require aur)
ttf-all-the-icons ttf-dejavu ttf-font-awesome-4 nerd-fonts-complete ttf-liberation

#AUR
yay

#File Management
zip p7zip file-roller unzip tumbler ffmpegthumbnailer imagemagick

#Terminal Extras
tty-clock curseradio-git cava wget

#Visuals:
compton dunst feh lxappearance numlockx rofi unclutter conky light xscreensaver

#Visuals Extra 
shantz-xwinwrap-bzr (Animated wallpaper - use command : xwinwrap -g 1920x1080 -ov -- mpv -wid WID ~/.wallpapers/water.mp4)

#Dependencies
coreutils mpv 

