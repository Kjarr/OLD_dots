  Add the settings.ini file to the GTK-3.0 folder in .config and the fonts/icon/theme folder to /USR/SHARE/ folder.
  
