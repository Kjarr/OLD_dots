## Folder Placement
Please add this folder and its contents into to .config folder. The FEH command found in the corresponding i3/config file.
Files in the options folder can be added to the main folder - they will then get randomly selected to be wallpaper.
